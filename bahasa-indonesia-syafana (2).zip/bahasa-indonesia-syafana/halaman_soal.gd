
extends Control

var daftar_soal = [
	{
		"soal": "Gagasan utama adalah ...",
		"pilihan": ["Ide pokok paragraf", "Kalimat penutup", "Contoh bacaan", "Pendapat pembaca"],
		"jawaban": 0
	},
	{
		"soal": "Sinonim kata cermat adalah ...",
		"pilihan": ["Ceroboh", "Teliti", "Lambat", "Malas"],
		"jawaban": 1
	},
	{
		"soal": "Kalimat efektif adalah ...",
		"pilihan": ["Para siswa-siswa belajar", "Dia naik ke atas", "Siswa mengikuti ujian", "Demi untuk sukses, belajar"],
		"jawaban": 2
	},
	{
		"soal": "Antonim kata optimis adalah ...",
		"pilihan": ["Yakin", "Semangat", "Pesimis", "Percaya"],
		"jawaban": 2
	},
	{
		"soal": "Tujuan teks argumentasi adalah ...",
		"pilihan": ["Menghibur pembaca", "Meyakinkan pembaca dengan alasan", "Menceritakan pengalaman", "Menggambarkan objek"],
		"jawaban": 1
	},
	{
		"soal": "Kalimat yang mengandung majas personifikasi adalah ...",
		"pilihan": ["Angin berbisik di antara pepohonan", "Wajahnya cantik seperti bunga", "Dia berlari sangat cepat", "Ayah membaca koran"],
		"jawaban": 0
	},
	{
		"soal": "Penulisan kata baku yang tepat adalah ...",
		"pilihan": ["Resiko", "Aktifitas", "Izin", "Apotik"],
		"jawaban": 2
	},
	{
		"soal": "Teks yang berisi langkah-langkah melakukan sesuatu disebut ...",
		"pilihan": ["Teks eksposisi", "Teks prosedur", "Teks narasi", "Teks deskripsi"],
		"jawaban": 1
	},
	{
		"soal": "Kalimat yang menggunakan konjungsi sebab-akibat adalah ...",
		"pilihan": ["Rina belajar dan adiknya bermain", "Ia rajin belajar sehingga mendapat nilai baik", "Ibu memasak ketika ayah pulang", "Dia tetap pergi meskipun hujan"],
		"jawaban": 1
	},
	{
		"soal": "Sudut pandang orang pertama biasanya ditandai dengan kata ...",
		"pilihan": ["Dia", "Mereka", "Aku", "Kamu"],
		"jawaban": 2
	}
]

var nomor_soal = 0
var skor = 0
var jawaban_user = []
var pilihan_terpilih = -1
var kuis_selesai = false

@onready var label_nomor = $LabelNomor
@onready var label_soal = $LabelSoal
@onready var label_skor = $LabelSkor

@onready var tombol_lanjut = $ButtonLanjut

@onready var tombol_kembali = $ButtonKembali

@onready var tombol_pilihan = [
	$LabelSoal2/VBoxPilihan/ButtonA,
	$LabelSoal2/VBoxPilihan/ButtonB,
	$LabelSoal2/VBoxPilihan/ButtonC,
	$LabelSoal2/VBoxPilihan/ButtonD
]


func _ready():
	jawaban_user.resize(daftar_soal.size())

	for i in range(4):
		var index = i

		tombol_pilihan[i].pressed.connect(
			func(): pilih_jawaban(index)
		)

	tombol_lanjut.pressed.connect(soal_selanjutnya)
	tombol_kembali.pressed.connect(kembali_ke_menu)

	muat_soal()


func muat_soal():
	pilihan_terpilih = -1

	var data = daftar_soal[nomor_soal]

	label_nomor.text = "Soal %d dari %d" % [
		nomor_soal + 1,
		daftar_soal.size()
	]

	label_soal.autowrap_mode = TextServer.AUTOWRAP_WORD
	label_soal.text = data["soal"]

	for i in range(4):
		tombol_pilihan[i].show()
		tombol_pilihan[i].text = data["pilihan"][i]
		tombol_pilihan[i].disabled = false

	tombol_lanjut.text = "LANJUT"
	tombol_lanjut.disabled = false

	label_skor.text = "Skor: %d" % skor


func pilih_jawaban(index):
	if pilihan_terpilih != -1:
		return

	pilihan_terpilih = index

	for i in range(4):
		tombol_pilihan[i].disabled = true


func soal_selanjutnya():
	if kuis_selesai:
		kembali_ke_menu()
		return

	if pilihan_terpilih == -1:
		return

	jawaban_user[nomor_soal] = pilihan_terpilih

	if nomor_soal < daftar_soal.size() - 1:
		nomor_soal += 1
		muat_soal()
	else:
		hitung_skor()


func hitung_skor():
	skor = 0

	for i in range(daftar_soal.size()):
		if jawaban_user[i] == daftar_soal[i]["jawaban"]:
			skor += 10

	kuis_selesai = true

	label_nomor.text = "KUIS SELESAI!"
	label_soal.text = "Nilai akhir kamu: %d dari 100" % skor
	label_skor.text = "Jawaban benar: %d dari 10" % (skor / 10)

	for tombol in tombol_pilihan:
		tombol.hide()

	tombol_lanjut.text = "SELESAI"
	tombol_lanjut.disabled = false


func kembali_ke_menu():
	get_tree().change_scene_to_file("res://main_menu.tscn")
